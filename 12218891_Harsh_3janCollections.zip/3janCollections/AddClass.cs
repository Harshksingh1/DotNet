using System;
class AddClass //non generic class
{
    public int AddInt(int n1,int n2)
    {
        return n1+n2;
    }
    public float AddFloat(float f1,float f2)
    {
        return f1+f2;
    }
    public string AddString(string s1,string s2)
    {
        return s1+s2;
    }
}